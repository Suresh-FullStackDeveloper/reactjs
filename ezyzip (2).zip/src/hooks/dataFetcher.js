import { useState, useEffect } from 'react';
import { getStories } from '../utils/apis';

//useState is a Hook that allows us to have state variables in functional components.
// we pass the initial state to this function and it returns a variable with the current state value 
//(not necessarily the initial state) and another function to update this value
const useDataFetcher = (type) => {
  // useState methods would always be executed in the same order, 
  //first returning the values of count1 , setCount1 , 
  //and then returning the values of name , setName . ... useState above, the first call should return the [count, setCount] and the second call should return [name, setName]
  const [stories, setStories] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!stories[type]) {
      setIsLoading(true);
      getStories(type)
        .then((stories) => {
          setStories((prevState) => ({
            ...prevState,
            [type]: stories
          }));
          setIsLoading(false);
        })
        .catch(() => {
          setIsLoading(false);
        });
    }
  }, [type]);
//loading 
  return { isLoading, stories: stories[type] };
};

export default useDataFetcher;
