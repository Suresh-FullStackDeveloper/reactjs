import axios from 'axios';
import { BASE_API_URL } from './constants';

const getStory = async (id) => {
  try {
    //adding methods to constant base url
    const { data } = await axios.get(`${BASE_API_URL}/item/${id}.json`);
    return data;
  } catch (error) {
    console.log('Error while getting a story.');
  }
};
//types of storeies 
///03/Mar/2021
//The word “async” before a function means one simple thing:
// a function always returns a promise. 
//Other values are wrapped in a resolved promise automatically.
export const getStories = async (type) => {
  try {
    
    const { data: storyIds } = await axios.get(
      `${BASE_API_URL}/${type}stories.json`
    );
    //The keyword await makes JavaScript wait until that promise settles and returns its result.
    const stories = await Promise.all(storyIds.slice(0, 30).map(getStory));
    return stories;
  } catch (error) {
    console.log('Error while getting list of stories.');
  }
};
